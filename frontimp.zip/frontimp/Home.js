import { React, Component } from 'react';
import './App.css';

class Home extends Component {

    render(){
        return(
            <h1>School application</h1>   
            
        );
  }
}
    export default Home;

