import React  from 'react';

import './App.css';
import  Student from './Student';
import  Home from './Home';
import {Route,Link} from "react-router-dom";
import NavBar from './NavBar';
import  Teacher from './Teacher';



function App() {
  return (
    <div className="App">
      
      
      {/* <img src="https://th.bing.com/th/id/OIP.-9j-aWzaNyqzajtbjP2ETgHaEK?pid=ImgDet&rs=1" /> */}
      <NavBar/>
      <Route exact path="/home" component={Home}/> 
      <Route  exact path="/student" component={Student}/> 
      <Route  exact path="/teacher" component={Teacher}/> 

    </div>
  );
}

export default App;
