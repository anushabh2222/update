
setInterval(function(){
    document.getElementById('blink').click();
    document.getElementById('blink').style="display:none";
}, 1000);

setInterval(function(){
    document.getElementById('blink').style="display:block";
}, 2000);
