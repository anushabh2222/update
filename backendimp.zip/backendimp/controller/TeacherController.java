package com.example.demo.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Response.Response;
import com.example.demo.Service.TeacherService;
import com.example.demo.model.Teacher;
import com.example.demo.repositories.TeacherRepository;



@RestController
@RequestMapping("/teach")
@CrossOrigin
public class TeacherController {
	@Autowired
	TeacherRepository teacherRepository;
	
	@Autowired
	TeacherService teacherService;
	
	@PostMapping("/create")
	public Response createTeacher(@RequestBody Teacher teacher) {
		
		 teacherRepository.insert(teacher);
		 return new Response("200"," created successfully ","data",true);
		
	}
	
	@GetMapping("/list")
	public List<Teacher> listTeachers(){
		return teacherRepository.findAll();
		
	}
	
	
	
	@PutMapping("/update")
	public Teacher update(@RequestBody Teacher teacher) {
		return teacherRepository.save(teacher);
	}
	
	@DeleteMapping("/delete/{id}")
	public Response deleteTeacher(@PathVariable String id) {
	
	boolean teacherexists=teacherRepository.existsById(id);
	if(teacherexists)
	{
		teacherRepository.deleteById(id);
		return new Response("200","successfully deleted","data",true);
	}
	return new Response("error"," id  is not present ","data",false);
	}
	
	
}

	
	
	
	


