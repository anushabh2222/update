package com.example.demo.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Response.Response;
import com.example.demo.Service.StudentService;
import com.example.demo.model.Student;
import com.example.demo.repositories.StudentRepository;



@RestController
@RequestMapping("/api")
@CrossOrigin
public class StudentController {

	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	StudentService studentService;
	
	
	
	@PostMapping("/create")
	public Response createStudent(@RequestBody Student student) {
		
		 studentRepository.insert(student);
		 return new Response("200"," created successfully ","data",true);
		
	}
	
	@GetMapping("/list")
	public List<Student> listStudents(){
		return studentRepository.findAll();
		
	}
	
	
	
	@PutMapping("/update")
	public Student update(@RequestBody Student student) {
		return studentRepository.save(student);
	}
	
	@DeleteMapping("/delete/{id}")
	public Response deleteStudent(@PathVariable String id) {
	
	boolean studentexists=studentRepository.existsById(id);
	if(studentexists)
	{
		studentRepository.deleteById(id);
		return new Response("200","successfully deleted","data",true);
	}
	return new Response("error"," id  is not present ","data",false);
	}
	
	
}
