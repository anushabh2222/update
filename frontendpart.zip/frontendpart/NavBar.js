import React,{Component} from 'react'
import {Link} from 'react-router-dom'

class NavBar extends Component {
    render(){
        return(
            <ul>
           
            <li>
            <Link to="/student">Student</Link>
            </li>
            <li>
            <Link to="/teacher">Teacher</Link>
            </li>
        </ul>
        );
  }
}
export default NavBar;