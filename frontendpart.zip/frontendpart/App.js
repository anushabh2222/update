import React  from 'react';

import './App.css';
import  Student from './Student';

import {Route} from "react-router-dom";
import NavBar from './NavBar';
import  Teacher from './Teacher';



function App() {
  return (
    <div className="App">
      
      
     
      <NavBar/>
     
      <Route  exact path="/student" component={Student}/> 
      <Route  exact path="/teacher" component={Teacher}/> 

    </div>
  );
}

export default App;
