package com.example.demo.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Response.Response;

import com.example.demo.model.Student;
import com.example.demo.repositories.StudentRepository;



@RestController
@RequestMapping("/api")
@CrossOrigin
public class StudentController {

	@Autowired
	StudentRepository studentRepository;
	
	
	
	
	@PostMapping("/create")
	public Response createStudent(@RequestBody Student student) {
		
		 studentRepository.insert(student);
		 return new Response("200"," created successfully ","data",true);
		
	}
	
	@GetMapping("/list")
	public List<Student> listStudents(){
		return studentRepository.findAll();
		
	}
	
	
	
	@PutMapping("/update")
	public Response updatebyId(@RequestBody Student student) 
	{
		try{
			boolean existStudent=studentRepository.existsById(student.getId());
			if(existStudent){

			
			studentRepository.save(student);
			return new Response("200","updated successfully","data",true);

		}
	}
	catch(Exception e){
		return new Response("500","not found","something went wrong",false);
	}
		return new Response("400","student not found","data",false);
	}
	
	@DeleteMapping("/delete/{id}")
	public Response deleteStudent(@PathVariable String id) {
	

	try
	{
		studentRepository.deleteById(id);
	}
	catch(Exception e){

		return new Response("400","not found",e,false);
	}
	return new Response("success","deleted successfully ",id,true);
	}
	
	
}
