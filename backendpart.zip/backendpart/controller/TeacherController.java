package com.example.demo.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Response.Response;

import com.example.demo.model.Teacher;
import com.example.demo.repositories.TeacherRepository;



@RestController
@RequestMapping("/teach")
@CrossOrigin
public class TeacherController {
	@Autowired
	TeacherRepository teacherRepository;
	
	
	
	@PostMapping("/create")
	public Response createTeacher(@RequestBody Teacher teacher) {
		
		 teacherRepository.insert(teacher);
		 return new Response("200"," created successfully ","data",true);
		
	}
	
	@GetMapping("/list")
	public List<Teacher> listTeachers(){
		return teacherRepository.findAll();
		
	}
	
	
	
	@PutMapping("/update")
	public Response updatebyId(@RequestBody Teacher teacher) 
	{
		try{
			boolean existTeacher=teacherRepository.existsById(teacher.getId());
			if(existTeacher){

			
			teacherRepository.save(teacher);
			return new Response("200","updated successfully","data",true);

		}
	}
	catch(Exception e){
		return new Response("500"," id not found","something went wrong",false);
	}
		return new Response("400","teacher not found","data",false);
	}
	
	@DeleteMapping("/delete/{id}")
	public Response deleteTeacher(@PathVariable String id) {
	

	try
	{
		teacherRepository.deleteById(id);
	}
	catch(Exception e){

		return new Response("400","not found",e,false);
	}
	return new Response("success","deleted successfully ",id,true);
	}
	
	
}

	
	
	
	


