package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection ="teacher")
public class Teacher {
	

@Id

private String id;
private String name;
private String specification;
private String createdate;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSpecification() {
	return specification;
}
public void setSpecification(String specification) {
	this.specification = specification;
}
public String getCreatedate() {
	return createdate;
}
public void setCreatedate(String createdate) {
	this.createdate = createdate;
}
@Override
public String toString() {
	return "Teacher [createdate=" + createdate + ", id=" + id + ", name=" + name + ", specification=" + specification
			+ "]";
}

	

}
